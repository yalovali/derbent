package lova.data;

public enum Role {
    USER, ADMIN;
}
