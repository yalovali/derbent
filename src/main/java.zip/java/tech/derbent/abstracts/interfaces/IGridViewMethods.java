package tech.derbent.abstracts.interfaces;
public interface IGridViewMethods {
	public static void createMaster() {
		// TODO Auto-generated method stub
	}
}
