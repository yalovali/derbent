package tech.derbent.abstracts.services;

public class CParentChildRelationRepository {
}
