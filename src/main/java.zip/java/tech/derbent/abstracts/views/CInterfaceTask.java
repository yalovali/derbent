package tech.derbent.abstracts.views;

import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public interface CInterfaceTask {
}
