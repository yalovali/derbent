package tech.derbent.activities.service;

import tech.derbent.abstracts.services.CEntityOfProjectRepository;
import tech.derbent.activities.domain.CActivityType;

public interface CActivityTypeRepository extends CEntityOfProjectRepository<CActivityType> {
}
