package tech.derbent.risks.domain;

public enum ERiskSeverity {
    LOW, MEDIUM, HIGH, CRITICAL
}
