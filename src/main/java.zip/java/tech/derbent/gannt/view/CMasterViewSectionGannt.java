package tech.derbent.gannt.view;

import tech.derbent.abstracts.domains.CProjectItem;
import tech.derbent.abstracts.views.grids.CMasterViewSectionBase;

public class CMasterViewSectionGannt<T extends CProjectItem<T>> extends CMasterViewSectionBase<T> {
	private static final long serialVersionUID = 1L;

	@Override
	public void createMasterView() {
		// implement master view
	}
}
