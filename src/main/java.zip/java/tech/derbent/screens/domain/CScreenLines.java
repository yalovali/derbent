package tech.derbent.screens.domain;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import tech.derbent.abstracts.annotations.AMetaData;
import tech.derbent.abstracts.domains.CEntityDB;

/** CScreenLines - Domain entity representing individual lines/fields in a screen definition. Layer: Domain (MVC) Each line represents a field that
 * should be displayed in the screen view. */
@Entity
@Table (name = "cscreen_lines")
@AttributeOverride (name = "id", column = @Column (name = "screen_line_id"))
public class CScreenLines extends CEntityDB<CScreenLines> {
	@ManyToOne (fetch = FetchType.LAZY)
	@JoinColumn (name = "screen_id", nullable = false)
	@NotNull (message = "Screen reference is required")
	@AMetaData (
			displayName = "Screen Reference", required = true, readOnly = false, description = "Screen Reference", hidden = false, order = 1,
			defaultValue = "1"
	)
	private CScreen screen;
	@Column (name = "line_order", nullable = false)
	@Min (value = 1, message = "Line order must be at least 1")
	@Max (value = 999, message = "Line order cannot exceed 999")
	@AMetaData (
			displayName = "Line Order", required = true, readOnly = false, description = "Order of this line in the screen (1-999)", hidden = false,
			order = 1, defaultValue = "0"
	)
	private Integer lineOrder = 0;
	@Column (name = "relationFieldName", nullable = false, length = 100)
	@Size (max = 100, message = "Relation Field Name cannot exceed 100 characters")
	@AMetaData (
			displayName = "Relation Field", required = true, readOnly = false, description = "Relation Field is designed for", hidden = false,
			order = 2, maxLength = 100, dataProviderBean = "none"
	)
	private String relationFieldName;
	@Column (name = "field_caption", nullable = false, length = 255)
	@Size (max = 255, message = "Field caption cannot exceed 255 characters")
	@NotNull (message = "Field caption is required")
	@AMetaData (
			displayName = "Field Caption", required = true, readOnly = false, description = "Caption/label to display for this field", hidden = false,
			order = 2, maxLength = 255
	)
	private String fieldCaption;
	@Column (name = "entity_property", nullable = false, length = 100)
	@Size (max = 100, message = "Field property name cannot exceed 100 characters")
	@NotNull (message = "Field propery name is required")
	@AMetaData (
			displayName = "Field Property", required = true, readOnly = false, description = "Name of the property in the entity", hidden = false,
			order = 3, maxLength = 100, dataProviderBean = "none"
	)
	private String entityProperty;
	@Column (name = "sectionName", nullable = true, length = 100)
	@Size (max = 100, message = "Name cannot exceed 100 characters")
	@AMetaData (
			displayName = "Field Property", required = false, readOnly = false, description = "Section of entries below", hidden = false, order = 3,
			maxLength = 100
	)
	private String sectionName;
	@Column (name = "field_description", nullable = true, length = 500)
	@Size (max = 500, message = "Field description cannot exceed 500 characters")
	@AMetaData (
			displayName = "Field Description", required = false, readOnly = false, description = "Description or help text for this field",
			hidden = false, order = 4, maxLength = 500
	)
	private String fieldDescription;
	@Column (name = "is_required", nullable = false)
	@AMetaData (
			displayName = "Required", required = false, readOnly = false, description = "Whether this field is required", hidden = false, order = 6,
			defaultValue = "false"
	)
	private Boolean isRequired = false;
	@Column (name = "is_readonly", nullable = false)
	@AMetaData (
			displayName = "Read Only", required = false, readOnly = false, description = "Whether this field is read-only", hidden = false, order = 7,
			defaultValue = "false"
	)
	private Boolean isReadonly = false;
	@Column (name = "is_hidden", nullable = false)
	@AMetaData (
			displayName = "Hidden", required = false, readOnly = false, description = "Whether this field is hidden", hidden = false, order = 8,
			defaultValue = "false"
	)
	private Boolean isHidden = false;
	@Column (name = "default_value", nullable = true, length = 255)
	@Size (max = 255, message = "Default value cannot exceed 255 characters")
	@AMetaData (
			displayName = "Default Value", required = false, readOnly = false, description = "Default value for this field", hidden = false,
			order = 9, maxLength = 255
	)
	private String defaultValue;
	@Column (name = "related_entity_type", nullable = true, length = 100)
	@Size (max = 100, message = "Related entity type cannot exceed 100 characters")
	@AMetaData (
			displayName = "Related Entity Type", required = false, readOnly = false, description = "Type of related entity for reference fields",
			hidden = false, order = 10, maxLength = 100
	)
	private String relatedEntityType;
	@Column (name = "data_provider_bean", nullable = true, length = 100)
	@Size (max = 100, message = "Data provider bean cannot exceed 100 characters")
	@AMetaData (
			displayName = "Data Provider Bean", required = false, readOnly = false,
			description = "Spring bean name for data provider (for comboboxes)", hidden = false, order = 11, maxLength = 100
	)
	private String dataProviderBean;
	@Column (name = "max_length", nullable = true)
	@Min (value = 1, message = "Max length must be at least 1")
	@Max (value = 10000, message = "Max length cannot exceed 10000")
	@AMetaData (
			displayName = "Max Length", required = false, readOnly = false, description = "Maximum length for text fields", hidden = false, order = 12
	)
	private Integer maxLength;
	@Column (name = "is_active", nullable = false)
	@AMetaData (
			displayName = "Active", required = false, readOnly = false, description = "Whether this line is active", hidden = false, order = 20,
			defaultValue = "true"
	)
	private Boolean isActive = true;

	/** Default constructor for JPA. */
	public CScreenLines() {
		super(CScreenLines.class);
	}

	public CScreenLines(final CScreen screen, final String relationFieldName, final String entityProperty) {
		super(CScreenLines.class);
		this.screen = screen;
		this.relationFieldName = relationFieldName;
		this.entityProperty = entityProperty;
	}
	// Getters and Setters

	public String getDataProviderBean() { return dataProviderBean; }

	public String getDefaultValue() { return defaultValue; }

	public String getEntityProperty() { return entityProperty; }

	public String getFieldCaption() { return fieldCaption; }

	public String getFieldDescription() { return fieldDescription; }

	public Boolean getIsActive() { return isActive; }

	public Boolean getIsHidden() { return isHidden; }

	public Boolean getIsReadonly() { return isReadonly; }

	public Boolean getIsRequired() { return isRequired; }

	public Integer getLineOrder() { return lineOrder; }

	public Integer getMaxLength() { return maxLength; }

	public String getRelatedEntityType() { return relatedEntityType; }

	public String getRelationFieldName() { return relationFieldName; }

	public CScreen getScreen() { return screen; }

	public String getSectionName() { return sectionName; }

	public void printLine() {
		System.out.println("CScreenLines{" + "id=" + getId() + ", lineOrder=" + lineOrder + ", fieldCaption='" + fieldCaption + '\''
				+ ", entityProperty='" + entityProperty + '\'' + ", relationFieldName='" + relationFieldName + '\'' + ", sectionName='" + sectionName
				+ '\'' + ", isActive=" + isActive + '}');
	}

	public void setDataProviderBean(final String dataProviderBean) { this.dataProviderBean = dataProviderBean; }

	public void setDefaultValue(final String defaultValue) { this.defaultValue = defaultValue; }

	public void setDescription(final String fieldDescription) { this.fieldDescription = fieldDescription; }

	public void setFieldCaption(final String fieldCaption) { this.fieldCaption = fieldCaption; }

	public void setIsActive(final Boolean isActive) { this.isActive = isActive; }

	public void setIsHidden(final Boolean isHidden) { this.isHidden = isHidden; }

	public void setIsReadonly(final Boolean isReadonly) { this.isReadonly = isReadonly; }

	public void setIsRequired(final Boolean isRequired) { this.isRequired = isRequired; }

	public void setLineOrder(final Integer lineOrder) { this.lineOrder = lineOrder; }

	public void setMaxLength(final Integer maxLength) { this.maxLength = maxLength; }

	public void setProperty(final String entityProperty) { this.entityProperty = entityProperty; }

	public void setRelatedEntityType(final String relatedEntityType) { this.relatedEntityType = relatedEntityType; }

	public void setRelationFieldName(final String relationFieldName) { this.relationFieldName = relationFieldName; }

	public void setScreen(final CScreen screen) { this.screen = screen; }

	public void setSectionName(final String sectionName) {
		this.sectionName = sectionName;
		this.fieldCaption = sectionName;
	}

	@Override
	public String toString() {
		return String.format("CScreenLines{id=%d, lineOrder=%d, fieldCaption='%s', entityProperty='%s'}", getId(), lineOrder, fieldCaption,
				entityProperty);
	}
}
